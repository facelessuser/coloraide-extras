"""Gamut mapping algorithms."""

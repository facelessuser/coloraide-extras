"""Distancing algorithms."""
